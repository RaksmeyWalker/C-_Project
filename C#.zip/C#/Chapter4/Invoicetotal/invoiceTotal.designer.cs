﻿namespace InvoiceTotal2
{
    partial class InvoiceTotal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblsubtotal = new System.Windows.Forms.Label();
            this.lbldiscountpercent = new System.Windows.Forms.Label();
            this.lbldiscountamount = new System.Windows.Forms.Label();
            this.lbltotal = new System.Windows.Forms.Label();
            this.txtSubtotal = new System.Windows.Forms.TextBox();
            this.txtDiscountPercent = new System.Windows.Forms.TextBox();
            this.txtDiscountAmount = new System.Windows.Forms.TextBox();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btbexit = new System.Windows.Forms.Button();
            this.lblentersubtotal = new System.Windows.Forms.Label();
            this.txtentersubtotal = new System.Windows.Forms.TextBox();
            this.lblnumberofinvoices = new System.Windows.Forms.Label();
            this.lbltotalofinvoices = new System.Windows.Forms.Label();
            this.lblinvoiceaverage = new System.Windows.Forms.Label();
            this.txtnumberofinvoices = new System.Windows.Forms.TextBox();
            this.txttotalofinvoices = new System.Windows.Forms.TextBox();
            this.txtinvoiceaverage = new System.Windows.Forms.TextBox();
            this.btncleartotals = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblsubtotal
            // 
            this.lblsubtotal.AutoSize = true;
            this.lblsubtotal.Location = new System.Drawing.Point(92, 58);
            this.lblsubtotal.Name = "lblsubtotal";
            this.lblsubtotal.Size = new System.Drawing.Size(59, 16);
            this.lblsubtotal.TabIndex = 0;
            this.lblsubtotal.Text = "Subtotal:";
            // 
            // lbldiscountpercent
            // 
            this.lbldiscountpercent.AutoSize = true;
            this.lbldiscountpercent.Location = new System.Drawing.Point(91, 110);
            this.lbldiscountpercent.Name = "lbldiscountpercent";
            this.lbldiscountpercent.Size = new System.Drawing.Size(111, 16);
            this.lbldiscountpercent.TabIndex = 1;
            this.lbldiscountpercent.Text = "Discount Percent:";
            // 
            // lbldiscountamount
            // 
            this.lbldiscountamount.AutoSize = true;
            this.lbldiscountamount.Location = new System.Drawing.Point(92, 171);
            this.lbldiscountamount.Name = "lbldiscountamount";
            this.lbldiscountamount.Size = new System.Drawing.Size(110, 16);
            this.lbldiscountamount.TabIndex = 2;
            this.lbldiscountamount.Text = "Discount Amount:";
            // 
            // lbltotal
            // 
            this.lbltotal.AutoSize = true;
            this.lbltotal.Location = new System.Drawing.Point(110, 244);
            this.lbltotal.Name = "lbltotal";
            this.lbltotal.Size = new System.Drawing.Size(41, 16);
            this.lbltotal.TabIndex = 3;
            this.lbltotal.Text = "Total:";
            // 
            // txtSubtotal
            // 
            this.txtSubtotal.Location = new System.Drawing.Point(267, 52);
            this.txtSubtotal.Name = "txtSubtotal";
            this.txtSubtotal.ReadOnly = true;
            this.txtSubtotal.Size = new System.Drawing.Size(100, 22);
            this.txtSubtotal.TabIndex = 1;
            this.txtSubtotal.TextChanged += new System.EventHandler(this.txtSubtotal_TextChanged);
            // 
            // txtDiscountPercent
            // 
            this.txtDiscountPercent.Location = new System.Drawing.Point(267, 107);
            this.txtDiscountPercent.Name = "txtDiscountPercent";
            this.txtDiscountPercent.ReadOnly = true;
            this.txtDiscountPercent.Size = new System.Drawing.Size(100, 22);
            this.txtDiscountPercent.TabIndex = 5;
            // 
            // txtDiscountAmount
            // 
            this.txtDiscountAmount.Location = new System.Drawing.Point(267, 168);
            this.txtDiscountAmount.Name = "txtDiscountAmount";
            this.txtDiscountAmount.ReadOnly = true;
            this.txtDiscountAmount.Size = new System.Drawing.Size(100, 22);
            this.txtDiscountAmount.TabIndex = 6;
            // 
            // txtTotal
            // 
            this.txtTotal.Location = new System.Drawing.Point(267, 244);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.ReadOnly = true;
            this.txtTotal.Size = new System.Drawing.Size(100, 22);
            this.txtTotal.TabIndex = 7;
            this.txtTotal.TabStop = false;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(151, 328);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(75, 23);
            this.btnCalculate.TabIndex = 2;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btbCalculate_Click);
            // 
            // btbexit
            // 
            this.btbexit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btbexit.Location = new System.Drawing.Point(592, 328);
            this.btbexit.Name = "btbexit";
            this.btbexit.Size = new System.Drawing.Size(75, 23);
            this.btbexit.TabIndex = 3;
            this.btbexit.Text = "Exit";
            this.btbexit.UseVisualStyleBackColor = true;
            this.btbexit.Click += new System.EventHandler(this.btbexit_Click);
            // 
            // lblentersubtotal
            // 
            this.lblentersubtotal.AutoSize = true;
            this.lblentersubtotal.Location = new System.Drawing.Point(92, 24);
            this.lblentersubtotal.Name = "lblentersubtotal";
            this.lblentersubtotal.Size = new System.Drawing.Size(93, 16);
            this.lblentersubtotal.TabIndex = 8;
            this.lblentersubtotal.Text = "Enter Subtotal:";
            // 
            // txtentersubtotal
            // 
            this.txtentersubtotal.Location = new System.Drawing.Point(267, 18);
            this.txtentersubtotal.Name = "txtentersubtotal";
            this.txtentersubtotal.Size = new System.Drawing.Size(100, 22);
            this.txtentersubtotal.TabIndex = 0;
            // 
            // lblnumberofinvoices
            // 
            this.lblnumberofinvoices.AutoSize = true;
            this.lblnumberofinvoices.Location = new System.Drawing.Point(461, 34);
            this.lblnumberofinvoices.Name = "lblnumberofinvoices";
            this.lblnumberofinvoices.Size = new System.Drawing.Size(125, 16);
            this.lblnumberofinvoices.TabIndex = 10;
            this.lblnumberofinvoices.Text = "Number of invoices:";
            // 
            // lbltotalofinvoices
            // 
            this.lbltotalofinvoices.AutoSize = true;
            this.lbltotalofinvoices.Location = new System.Drawing.Point(461, 104);
            this.lbltotalofinvoices.Name = "lbltotalofinvoices";
            this.lbltotalofinvoices.Size = new System.Drawing.Size(108, 16);
            this.lbltotalofinvoices.TabIndex = 11;
            this.lbltotalofinvoices.Text = "Total of invoices:";
            // 
            // lblinvoiceaverage
            // 
            this.lblinvoiceaverage.AutoSize = true;
            this.lblinvoiceaverage.Location = new System.Drawing.Point(461, 171);
            this.lblinvoiceaverage.Name = "lblinvoiceaverage";
            this.lblinvoiceaverage.Size = new System.Drawing.Size(107, 16);
            this.lblinvoiceaverage.TabIndex = 12;
            this.lblinvoiceaverage.Text = "Invoice average:";
            // 
            // txtnumberofinvoices
            // 
            this.txtnumberofinvoices.Location = new System.Drawing.Point(614, 34);
            this.txtnumberofinvoices.Name = "txtnumberofinvoices";
            this.txtnumberofinvoices.ReadOnly = true;
            this.txtnumberofinvoices.Size = new System.Drawing.Size(100, 22);
            this.txtnumberofinvoices.TabIndex = 13;
            // 
            // txttotalofinvoices
            // 
            this.txttotalofinvoices.Location = new System.Drawing.Point(614, 104);
            this.txttotalofinvoices.Name = "txttotalofinvoices";
            this.txttotalofinvoices.ReadOnly = true;
            this.txttotalofinvoices.Size = new System.Drawing.Size(100, 22);
            this.txttotalofinvoices.TabIndex = 14;
            // 
            // txtinvoiceaverage
            // 
            this.txtinvoiceaverage.Location = new System.Drawing.Point(614, 180);
            this.txtinvoiceaverage.Name = "txtinvoiceaverage";
            this.txtinvoiceaverage.ReadOnly = true;
            this.txtinvoiceaverage.Size = new System.Drawing.Size(100, 22);
            this.txtinvoiceaverage.TabIndex = 15;
            // 
            // btncleartotals
            // 
            this.btncleartotals.Location = new System.Drawing.Point(365, 340);
            this.btncleartotals.Name = "btncleartotals";
            this.btncleartotals.Size = new System.Drawing.Size(75, 23);
            this.btncleartotals.TabIndex = 16;
            this.btncleartotals.Text = "Clear Totals:";
            this.btncleartotals.UseVisualStyleBackColor = true;
            this.btncleartotals.Click += new System.EventHandler(this.btncleartotals_Click);
            // 
            // InvoiceTotal
            // 
            this.AcceptButton = this.btnCalculate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btbexit;
            this.ClientSize = new System.Drawing.Size(775, 450);
            this.Controls.Add(this.btncleartotals);
            this.Controls.Add(this.txtinvoiceaverage);
            this.Controls.Add(this.txttotalofinvoices);
            this.Controls.Add(this.txtnumberofinvoices);
            this.Controls.Add(this.lblinvoiceaverage);
            this.Controls.Add(this.lbltotalofinvoices);
            this.Controls.Add(this.lblnumberofinvoices);
            this.Controls.Add(this.txtentersubtotal);
            this.Controls.Add(this.lblentersubtotal);
            this.Controls.Add(this.btbexit);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.txtDiscountAmount);
            this.Controls.Add(this.txtDiscountPercent);
            this.Controls.Add(this.txtSubtotal);
            this.Controls.Add(this.lbltotal);
            this.Controls.Add(this.lbldiscountamount);
            this.Controls.Add(this.lbldiscountpercent);
            this.Controls.Add(this.lblsubtotal);
            this.Name = "InvoiceTotal";
            this.Text = "Invoice Total";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblsubtotal;
        private System.Windows.Forms.Label lbldiscountpercent;
        private System.Windows.Forms.Label lbldiscountamount;
        private System.Windows.Forms.Label lbltotal;
        private System.Windows.Forms.TextBox txtSubtotal;
        private System.Windows.Forms.TextBox txtDiscountPercent;
        private System.Windows.Forms.TextBox txtDiscountAmount;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btbexit;
        private System.Windows.Forms.Label lblentersubtotal;
        private System.Windows.Forms.TextBox txtentersubtotal;
        private System.Windows.Forms.Label lblnumberofinvoices;
        private System.Windows.Forms.Label lbltotalofinvoices;
        private System.Windows.Forms.Label lblinvoiceaverage;
        private System.Windows.Forms.TextBox txtnumberofinvoices;
        private System.Windows.Forms.TextBox txttotalofinvoices;
        private System.Windows.Forms.TextBox txtinvoiceaverage;
        private System.Windows.Forms.Button btncleartotals;
    }
}

