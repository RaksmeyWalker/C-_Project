﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BugTrouble
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculationwhenhouseisfull_Click(object sender, EventArgs e)
        {
            int volumeHouse = Convert.ToInt32(txtVolumeofyourhouseincubicfeet.Text);
            double numberRoachInhouse = Convert.ToInt32(txtNumberofroachesinyourhouse.Text);
            int weekUntilHouseisFull = 0;

            double roachesUntilFull = volumeHouse / 0.002;

            while (numberRoachInhouse <= roachesUntilFull)
            {
                numberRoachInhouse = numberRoachInhouse * (1 + 0.95);
                numberRoachInhouse++;
                weekUntilHouseisFull++;
            }
            txtWeeksunithousetofull.Text = weekUntilHouseisFull.ToString();
            txtTotalnumberofroaches.Text = numberRoachInhouse.ToString("N0");
            txtVolumeofyourhouseincubicfeet.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
