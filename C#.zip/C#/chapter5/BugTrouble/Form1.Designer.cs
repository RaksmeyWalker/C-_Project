﻿namespace BugTrouble
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtVolumeofyourhouseincubicfeet = new System.Windows.Forms.TextBox();
            this.txtNumberofroachesinyourhouse = new System.Windows.Forms.TextBox();
            this.txtWeeksunithousetofull = new System.Windows.Forms.TextBox();
            this.txtTotalnumberofroaches = new System.Windows.Forms.TextBox();
            this.btnCalculationwhenhouseisfull = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(209, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Volume of your house in cubic feet";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(203, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Number of roaches in your house";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(53, 136);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "Weeks unit house to full";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(56, 193);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(152, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "Total number of roaches";
            // 
            // txtVolumeofyourhouseincubicfeet
            // 
            this.txtVolumeofyourhouseincubicfeet.Location = new System.Drawing.Point(362, 35);
            this.txtVolumeofyourhouseincubicfeet.Name = "txtVolumeofyourhouseincubicfeet";
            this.txtVolumeofyourhouseincubicfeet.Size = new System.Drawing.Size(100, 22);
            this.txtVolumeofyourhouseincubicfeet.TabIndex = 1;
            this.txtVolumeofyourhouseincubicfeet.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNumberofroachesinyourhouse
            // 
            this.txtNumberofroachesinyourhouse.Location = new System.Drawing.Point(362, 79);
            this.txtNumberofroachesinyourhouse.Name = "txtNumberofroachesinyourhouse";
            this.txtNumberofroachesinyourhouse.Size = new System.Drawing.Size(100, 22);
            this.txtNumberofroachesinyourhouse.TabIndex = 2;
            this.txtNumberofroachesinyourhouse.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtWeeksunithousetofull
            // 
            this.txtWeeksunithousetofull.Location = new System.Drawing.Point(362, 130);
            this.txtWeeksunithousetofull.Name = "txtWeeksunithousetofull";
            this.txtWeeksunithousetofull.Size = new System.Drawing.Size(100, 22);
            this.txtWeeksunithousetofull.TabIndex = 3;
            this.txtWeeksunithousetofull.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTotalnumberofroaches
            // 
            this.txtTotalnumberofroaches.Location = new System.Drawing.Point(364, 187);
            this.txtTotalnumberofroaches.Name = "txtTotalnumberofroaches";
            this.txtTotalnumberofroaches.Size = new System.Drawing.Size(100, 22);
            this.txtTotalnumberofroaches.TabIndex = 4;
            this.txtTotalnumberofroaches.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnCalculationwhenhouseisfull
            // 
            this.btnCalculationwhenhouseisfull.Location = new System.Drawing.Point(106, 260);
            this.btnCalculationwhenhouseisfull.Name = "btnCalculationwhenhouseisfull";
            this.btnCalculationwhenhouseisfull.Size = new System.Drawing.Size(73, 64);
            this.btnCalculationwhenhouseisfull.TabIndex = 5;
            this.btnCalculationwhenhouseisfull.Text = "&Calculation when house is full";
            this.btnCalculationwhenhouseisfull.UseVisualStyleBackColor = true;
            this.btnCalculationwhenhouseisfull.Click += new System.EventHandler(this.btnCalculationwhenhouseisfull_Click);
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(362, 261);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 63);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.btnCalculationwhenhouseisfull;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCalculationwhenhouseisfull);
            this.Controls.Add(this.txtTotalnumberofroaches);
            this.Controls.Add(this.txtWeeksunithousetofull);
            this.Controls.Add(this.txtNumberofroachesinyourhouse);
            this.Controls.Add(this.txtVolumeofyourhouseincubicfeet);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "bug Trouble";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtVolumeofyourhouseincubicfeet;
        private System.Windows.Forms.TextBox txtNumberofroachesinyourhouse;
        private System.Windows.Forms.TextBox txtWeeksunithousetofull;
        private System.Windows.Forms.TextBox txtTotalnumberofroaches;
        private System.Windows.Forms.Button btnCalculationwhenhouseisfull;
        private System.Windows.Forms.Button btnExit;
    }
}

