﻿namespace CalculateLetterGrade
{
    partial class CalculateletterGrade
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNumericGrade = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtnumericgrade = new System.Windows.Forms.TextBox();
            this.lblGrade = new System.Windows.Forms.Label();
            this.btnCalculateLetterGrade = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblgradebox = new System.Windows.Forms.Label();
            this.txtlettergrade = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblNumericGrade
            // 
            this.lblNumericGrade.AutoSize = true;
            this.lblNumericGrade.Location = new System.Drawing.Point(89, 52);
            this.lblNumericGrade.Name = "lblNumericGrade";
            this.lblNumericGrade.Size = new System.Drawing.Size(101, 16);
            this.lblNumericGrade.TabIndex = 0;
            this.lblNumericGrade.Text = "Numeric Grade:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(89, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Letter Grade:";
            // 
            // txtnumericgrade
            // 
            this.txtnumericgrade.Location = new System.Drawing.Point(246, 52);
            this.txtnumericgrade.Name = "txtnumericgrade";
            this.txtnumericgrade.Size = new System.Drawing.Size(100, 22);
            this.txtnumericgrade.TabIndex = 2;
            // 
            // lblGrade
            // 
            this.lblGrade.AutoSize = true;
            this.lblGrade.Location = new System.Drawing.Point(329, 149);
            this.lblGrade.Name = "lblGrade";
            this.lblGrade.Size = new System.Drawing.Size(0, 16);
            this.lblGrade.TabIndex = 3;
            // 
            // btnCalculateLetterGrade
            // 
            this.btnCalculateLetterGrade.Location = new System.Drawing.Point(101, 201);
            this.btnCalculateLetterGrade.Name = "btnCalculateLetterGrade";
            this.btnCalculateLetterGrade.Size = new System.Drawing.Size(128, 42);
            this.btnCalculateLetterGrade.TabIndex = 4;
            this.btnCalculateLetterGrade.Text = "&Calculate Letter Grade";
            this.btnCalculateLetterGrade.UseVisualStyleBackColor = true;
            this.btnCalculateLetterGrade.Click += new System.EventHandler(this.btnCalculateLetterGrade_Click);
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(284, 201);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 42);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblgradebox
            // 
            this.lblgradebox.AutoSize = true;
            this.lblgradebox.Location = new System.Drawing.Point(346, 148);
            this.lblgradebox.Name = "lblgradebox";
            this.lblgradebox.Size = new System.Drawing.Size(0, 16);
            this.lblgradebox.TabIndex = 6;
            // 
            // txtlettergrade
            // 
            this.txtlettergrade.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtlettergrade.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.txtlettergrade.Location = new System.Drawing.Point(246, 129);
            this.txtlettergrade.Name = "txtlettergrade";
            this.txtlettergrade.Size = new System.Drawing.Size(100, 23);
            this.txtlettergrade.TabIndex = 7;
            // 
            // CalculateletterGrade
            // 
            this.AcceptButton = this.btnCalculateLetterGrade;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtlettergrade);
            this.Controls.Add(this.lblgradebox);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCalculateLetterGrade);
            this.Controls.Add(this.lblGrade);
            this.Controls.Add(this.txtnumericgrade);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblNumericGrade);
            this.Name = "CalculateletterGrade";
            this.Text = "Calculate Letter Grade";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNumericGrade;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtnumericgrade;
        private System.Windows.Forms.Label lblGrade;
        private System.Windows.Forms.Button btnCalculateLetterGrade;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblgradebox;
        private System.Windows.Forms.Label txtlettergrade;
    }
}

