﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculateLetterGrade
{
    public partial class CalculateletterGrade : Form
    {
        public CalculateletterGrade()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnCalculateLetterGrade_Click(object sender, EventArgs e)
        {
            decimal NumericGrade = Convert.ToDecimal(txtnumericgrade.Text);

            if (NumericGrade >= 100)
            {
                txtlettergrade.Text = "A";
            }
            else if (NumericGrade >= 80)
            {
                txtlettergrade.Text = "B";

            }
            else if (NumericGrade >= 70)
            {
                txtlettergrade.Text = "C";
            }
            else if (NumericGrade >= 60)
            {
                txtlettergrade.Text = "D";
            }
            else
            {
                txtlettergrade.Text = "F";
            }
            txtnumericgrade.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
