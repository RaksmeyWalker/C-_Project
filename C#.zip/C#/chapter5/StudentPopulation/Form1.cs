﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DtudentPopulation
{
    public partial class Studentpopulation : Form
    {
        public Studentpopulation()
        {
            InitializeComponent();
        }

        private void btnProjectStudentpopulation_Click(object sender, EventArgs e)
        {
            decimal NumberStudentToday = Convert.ToDecimal(txtnumberofstudenttoday.Text);
            decimal AnnualGrowthRate = Convert.ToDecimal(txtannualgrowthrate.Text);
            decimal NumberOfyear = Convert.ToDecimal(txtnumberofyears.Text);
            decimal ProjectNumberStudent;
            for (int Year = 1; Year <= NumberOfyear; Year++)
            {
                NumberStudentToday = NumberStudentToday * (1 + AnnualGrowthRate);
            }
            txtprojectnumberofstudents.Text = NumberStudentToday.ToString("n0");
            txtnumberofstudenttoday.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
