﻿namespace DtudentPopulation
{
    partial class Studentpopulation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNumberofstudenttoday = new System.Windows.Forms.Label();
            this.lblAnnualgrowthrate = new System.Windows.Forms.Label();
            this.lblNumberofyears = new System.Windows.Forms.Label();
            this.lblProjectnumberofstudents = new System.Windows.Forms.Label();
            this.btnProjectStudentpopulation = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.txtprojectnumberofstudents = new System.Windows.Forms.TextBox();
            this.txtnumberofstudenttoday = new System.Windows.Forms.TextBox();
            this.txtannualgrowthrate = new System.Windows.Forms.TextBox();
            this.txtnumberofyears = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblNumberofstudenttoday
            // 
            this.lblNumberofstudenttoday.AutoSize = true;
            this.lblNumberofstudenttoday.Location = new System.Drawing.Point(115, 82);
            this.lblNumberofstudenttoday.Name = "lblNumberofstudenttoday";
            this.lblNumberofstudenttoday.Size = new System.Drawing.Size(152, 16);
            this.lblNumberofstudenttoday.TabIndex = 0;
            this.lblNumberofstudenttoday.Text = "Number of student today";
            // 
            // lblAnnualgrowthrate
            // 
            this.lblAnnualgrowthrate.AutoSize = true;
            this.lblAnnualgrowthrate.Location = new System.Drawing.Point(118, 131);
            this.lblAnnualgrowthrate.Name = "lblAnnualgrowthrate";
            this.lblAnnualgrowthrate.Size = new System.Drawing.Size(116, 16);
            this.lblAnnualgrowthrate.TabIndex = 0;
            this.lblAnnualgrowthrate.Text = "Annual growth rate";
            // 
            // lblNumberofyears
            // 
            this.lblNumberofyears.AutoSize = true;
            this.lblNumberofyears.Location = new System.Drawing.Point(118, 179);
            this.lblNumberofyears.Name = "lblNumberofyears";
            this.lblNumberofyears.Size = new System.Drawing.Size(106, 16);
            this.lblNumberofyears.TabIndex = 0;
            this.lblNumberofyears.Text = "Number of years";
            // 
            // lblProjectnumberofstudents
            // 
            this.lblProjectnumberofstudents.AutoSize = true;
            this.lblProjectnumberofstudents.Location = new System.Drawing.Point(118, 242);
            this.lblProjectnumberofstudents.Name = "lblProjectnumberofstudents";
            this.lblProjectnumberofstudents.Size = new System.Drawing.Size(164, 16);
            this.lblProjectnumberofstudents.TabIndex = 0;
            this.lblProjectnumberofstudents.Text = "Project number of students";
            // 
            // btnProjectStudentpopulation
            // 
            this.btnProjectStudentpopulation.Location = new System.Drawing.Point(175, 342);
            this.btnProjectStudentpopulation.Name = "btnProjectStudentpopulation";
            this.btnProjectStudentpopulation.Size = new System.Drawing.Size(107, 62);
            this.btnProjectStudentpopulation.TabIndex = 5;
            this.btnProjectStudentpopulation.Text = "&Project Student population";
            this.btnProjectStudentpopulation.UseVisualStyleBackColor = true;
            this.btnProjectStudentpopulation.Click += new System.EventHandler(this.btnProjectStudentpopulation_Click);
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(375, 342);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 62);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // txtprojectnumberofstudents
            // 
            this.txtprojectnumberofstudents.Location = new System.Drawing.Point(323, 242);
            this.txtprojectnumberofstudents.Name = "txtprojectnumberofstudents";
            this.txtprojectnumberofstudents.ReadOnly = true;
            this.txtprojectnumberofstudents.Size = new System.Drawing.Size(100, 22);
            this.txtprojectnumberofstudents.TabIndex = 4;
            this.txtprojectnumberofstudents.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtnumberofstudenttoday
            // 
            this.txtnumberofstudenttoday.Location = new System.Drawing.Point(323, 79);
            this.txtnumberofstudenttoday.Name = "txtnumberofstudenttoday";
            this.txtnumberofstudenttoday.Size = new System.Drawing.Size(100, 22);
            this.txtnumberofstudenttoday.TabIndex = 1;
            this.txtnumberofstudenttoday.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtannualgrowthrate
            // 
            this.txtannualgrowthrate.Location = new System.Drawing.Point(323, 142);
            this.txtannualgrowthrate.Name = "txtannualgrowthrate";
            this.txtannualgrowthrate.Size = new System.Drawing.Size(100, 22);
            this.txtannualgrowthrate.TabIndex = 2;
            this.txtannualgrowthrate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtnumberofyears
            // 
            this.txtnumberofyears.Location = new System.Drawing.Point(323, 193);
            this.txtnumberofyears.Name = "txtnumberofyears";
            this.txtnumberofyears.Size = new System.Drawing.Size(100, 22);
            this.txtnumberofyears.TabIndex = 3;
            this.txtnumberofyears.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Studentpopulation
            // 
            this.AcceptButton = this.btnProjectStudentpopulation;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtnumberofyears);
            this.Controls.Add(this.txtannualgrowthrate);
            this.Controls.Add(this.txtnumberofstudenttoday);
            this.Controls.Add(this.txtprojectnumberofstudents);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnProjectStudentpopulation);
            this.Controls.Add(this.lblProjectnumberofstudents);
            this.Controls.Add(this.lblNumberofyears);
            this.Controls.Add(this.lblAnnualgrowthrate);
            this.Controls.Add(this.lblNumberofstudenttoday);
            this.Name = "Studentpopulation";
            this.Text = "Student Population";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNumberofstudenttoday;
        private System.Windows.Forms.Label lblAnnualgrowthrate;
        private System.Windows.Forms.Label lblNumberofyears;
        private System.Windows.Forms.Label lblProjectnumberofstudents;
        private System.Windows.Forms.Button btnProjectStudentpopulation;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtprojectnumberofstudents;
        private System.Windows.Forms.TextBox txtnumberofstudenttoday;
        private System.Windows.Forms.TextBox txtannualgrowthrate;
        private System.Windows.Forms.TextBox txtnumberofyears;
    }
}

