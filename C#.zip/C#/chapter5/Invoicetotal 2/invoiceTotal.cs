﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InvoiceTotal2
{
    public partial class InvoiceTotal : Form
    {
        public InvoiceTotal()
        {
            InitializeComponent();
        }

        private void txtSubtotal_TextChanged(object sender, EventArgs e)
        {

        }

        private void btbCalculate_Click(object sender, EventArgs e)
        {
            string customerType = txtCustomertype.Text;
            decimal subtotal = Convert.ToDecimal(txtSubtotal.Text);
            decimal discountPercent = 0m;
            if (customerType == "r" || customerType == "R")
            {
                if (subtotal < 250)
                    discountPercent = .0m;
                else if (subtotal >= 250 && subtotal < 500)
                    discountPercent = .25m;
                else
                    discountPercent = .30m;

            }
            else if (customerType == "C" || customerType == "c")
            {
                discountPercent = .20m;
            }
            else if (customerType == "T" || customerType == "t")
            {
                if (subtotal < 500)
                    discountPercent = .40m;
                else
                    discountPercent = .50m;
            }
            else
            {
                discountPercent = .10m;
            }
            decimal discountAmount = subtotal * discountPercent;
            decimal invoiceTotal = subtotal - discountAmount;
            txtDiscountPercent.Text = discountPercent.ToString("p1");
            txtDiscountAmount.Text = discountAmount.ToString("c");
            txtTotal.Text = invoiceTotal.ToString("c");
            txtCustomertype.Focus();
        }

        private void btbexit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtCustomertype_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
