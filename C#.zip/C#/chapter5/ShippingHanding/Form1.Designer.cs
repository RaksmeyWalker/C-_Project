﻿namespace Sippingandhanding
{
    partial class SippingandHandling
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblOrderTotal = new System.Windows.Forms.Label();
            this.lblCustomer = new System.Windows.Forms.Label();
            this.lblshipping = new System.Windows.Forms.Label();
            this.lblsales = new System.Windows.Forms.Label();
            this.lblGrandTotal = new System.Windows.Forms.Label();
            this.btnCalculateGrandTotal = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.txtsalestax = new System.Windows.Forms.TextBox();
            this.txtshippingcosts = new System.Windows.Forms.TextBox();
            this.txtordertotal = new System.Windows.Forms.TextBox();
            this.txtcustomertype = new System.Windows.Forms.TextBox();
            this.txtgrandtotal = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblOrderTotal
            // 
            this.lblOrderTotal.AutoSize = true;
            this.lblOrderTotal.Location = new System.Drawing.Point(74, 48);
            this.lblOrderTotal.Name = "lblOrderTotal";
            this.lblOrderTotal.Size = new System.Drawing.Size(75, 16);
            this.lblOrderTotal.TabIndex = 0;
            this.lblOrderTotal.Text = "Order Total";
            // 
            // lblCustomer
            // 
            this.lblCustomer.AutoSize = true;
            this.lblCustomer.Location = new System.Drawing.Point(71, 110);
            this.lblCustomer.Name = "lblCustomer";
            this.lblCustomer.Size = new System.Drawing.Size(268, 16);
            this.lblCustomer.TabIndex = 1;
            this.lblCustomer.Text = "Customer Type (Preferred N=non-Preferred)";
            // 
            // lblshipping
            // 
            this.lblshipping.AutoSize = true;
            this.lblshipping.Location = new System.Drawing.Point(74, 166);
            this.lblshipping.Name = "lblshipping";
            this.lblshipping.Size = new System.Drawing.Size(266, 16);
            this.lblshipping.TabIndex = 2;
            this.lblshipping.Text = "Shipping Costs (free for Preferred customer)";
            // 
            // lblsales
            // 
            this.lblsales.AutoSize = true;
            this.lblsales.Location = new System.Drawing.Point(74, 220);
            this.lblsales.Name = "lblsales";
            this.lblsales.Size = new System.Drawing.Size(98, 16);
            this.lblsales.TabIndex = 3;
            this.lblsales.Text = "Sales Tax (7%)";
            // 
            // lblGrandTotal
            // 
            this.lblGrandTotal.AutoSize = true;
            this.lblGrandTotal.Location = new System.Drawing.Point(74, 275);
            this.lblGrandTotal.Name = "lblGrandTotal";
            this.lblGrandTotal.Size = new System.Drawing.Size(78, 16);
            this.lblGrandTotal.TabIndex = 4;
            this.lblGrandTotal.Text = "Grand Total";
            // 
            // btnCalculateGrandTotal
            // 
            this.btnCalculateGrandTotal.Location = new System.Drawing.Point(165, 332);
            this.btnCalculateGrandTotal.Name = "btnCalculateGrandTotal";
            this.btnCalculateGrandTotal.Size = new System.Drawing.Size(93, 45);
            this.btnCalculateGrandTotal.TabIndex = 5;
            this.btnCalculateGrandTotal.Text = "&Calculate Grand Total";
            this.btnCalculateGrandTotal.UseVisualStyleBackColor = true;
            this.btnCalculateGrandTotal.Click += new System.EventHandler(this.btnCalculateGrandTotal_Click);
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(367, 332);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 45);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // txtsalestax
            // 
            this.txtsalestax.Location = new System.Drawing.Point(367, 220);
            this.txtsalestax.Name = "txtsalestax";
            this.txtsalestax.ReadOnly = true;
            this.txtsalestax.Size = new System.Drawing.Size(100, 22);
            this.txtsalestax.TabIndex = 7;
            this.txtsalestax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtsalestax.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtshippingcosts
            // 
            this.txtshippingcosts.Location = new System.Drawing.Point(367, 166);
            this.txtshippingcosts.Name = "txtshippingcosts";
            this.txtshippingcosts.ReadOnly = true;
            this.txtshippingcosts.Size = new System.Drawing.Size(100, 22);
            this.txtshippingcosts.TabIndex = 8;
            this.txtshippingcosts.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtordertotal
            // 
            this.txtordertotal.Location = new System.Drawing.Point(367, 48);
            this.txtordertotal.Name = "txtordertotal";
            this.txtordertotal.Size = new System.Drawing.Size(100, 22);
            this.txtordertotal.TabIndex = 9;
            this.txtordertotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtcustomertype
            // 
            this.txtcustomertype.Location = new System.Drawing.Point(367, 110);
            this.txtcustomertype.Name = "txtcustomertype";
            this.txtcustomertype.Size = new System.Drawing.Size(36, 22);
            this.txtcustomertype.TabIndex = 10;
            this.txtcustomertype.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtgrandtotal
            // 
            this.txtgrandtotal.Location = new System.Drawing.Point(367, 275);
            this.txtgrandtotal.Name = "txtgrandtotal";
            this.txtgrandtotal.ReadOnly = true;
            this.txtgrandtotal.Size = new System.Drawing.Size(100, 22);
            this.txtgrandtotal.TabIndex = 11;
            this.txtgrandtotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // SippingandHandling
            // 
            this.AcceptButton = this.btnCalculateGrandTotal;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtgrandtotal);
            this.Controls.Add(this.txtcustomertype);
            this.Controls.Add(this.txtordertotal);
            this.Controls.Add(this.txtshippingcosts);
            this.Controls.Add(this.txtsalestax);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCalculateGrandTotal);
            this.Controls.Add(this.lblGrandTotal);
            this.Controls.Add(this.lblsales);
            this.Controls.Add(this.lblshipping);
            this.Controls.Add(this.lblCustomer);
            this.Controls.Add(this.lblOrderTotal);
            this.Name = "SippingandHandling";
            this.Text = "Sipping and Handling";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblOrderTotal;
        private System.Windows.Forms.Label lblCustomer;
        private System.Windows.Forms.Label lblshipping;
        private System.Windows.Forms.Label lblsales;
        private System.Windows.Forms.Label lblGrandTotal;
        private System.Windows.Forms.Button btnCalculateGrandTotal;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtsalestax;
        private System.Windows.Forms.TextBox txtshippingcosts;
        private System.Windows.Forms.TextBox txtordertotal;
        private System.Windows.Forms.TextBox txtcustomertype;
        private System.Windows.Forms.TextBox txtgrandtotal;
    }
}

