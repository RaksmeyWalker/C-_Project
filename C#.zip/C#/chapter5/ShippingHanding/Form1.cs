﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sippingandhanding
{
    public partial class SippingandHandling : Form
    {
        public SippingandHandling()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalculateGrandTotal_Click(object sender, EventArgs e)
        {
            decimal shippingcosts = 0;
            decimal tax;
            decimal OrdersTotal = Convert.ToDecimal(txtordertotal.Text);
            decimal grandtotal;

            if (txtcustomertype.Text == "P" || txtcustomertype.Text == "p")
            {
                shippingcosts = .0m;
                txtshippingcosts.Text = shippingcosts.ToString("c");
            }
            else
            {
                if (txtshippingcosts.Text == "N" || txtshippingcosts.Text == "n")
                {
                    if (OrdersTotal < 25)
                    {
                        shippingcosts = 5;
                        txtshippingcosts.Text = shippingcosts.ToString("c");

                    }
                    else if (OrdersTotal < 500)
                    {
                        shippingcosts = 8;
                        txtshippingcosts.Text = shippingcosts.ToString("c");
                    }
                    else if (OrdersTotal < 1000)
                    {
                        shippingcosts = 10;
                        txtshippingcosts.Text = shippingcosts.ToString("c");
                    }
                    else if (OrdersTotal < 5000)
                    {
                        shippingcosts = 15;
                        txtshippingcosts.Text = shippingcosts.ToString("c");
                    }
                    else
                    {
                        shippingcosts = 20;
                        txtshippingcosts.Text = shippingcosts.ToString("c");
                    }

                }
            }
            tax = (7 * (shippingcosts + OrdersTotal)) / 100;
            txtsalestax.Text = tax.ToString("c");
            grandtotal = (shippingcosts + OrdersTotal) + tax;
            txtgrandtotal.Text = grandtotal.ToString("c");
            txtordertotal.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
