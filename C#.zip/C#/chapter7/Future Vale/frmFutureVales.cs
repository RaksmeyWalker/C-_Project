﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Future_Value
{
    public partial class frmFutureVales : Form
    {
        public frmFutureVales()
        {
            InitializeComponent();
        }

        private void btncaluclate_Click(object sender, EventArgs e)
        {
            try
            {
                if (IsValidData())
                {
                    decimal monthlyInvestment = Convert.ToDecimal(txtmonthlyinvestment.Text);
                    decimal yearlyInterestRate = Convert.ToDecimal(txtyearlyinterestrate.Text);
                    int years = Convert.ToInt32(txtnumberofyears.Text);

                    int months = years * 12;
                    decimal monthlyInterestRate = yearlyInterestRate / 12 / 100;

                    decimal futureValue = this.CalculateFutureValue(monthlyInvestment, monthlyInterestRate, months);
                    txtfuturevales.Text = futureValue.ToString("c");
                    txtmonthlyinvestment.Focus();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n\n" + ex.GetType().ToString() + "\n" + ex.StackTrace, "Exception");
            }
        }
        private decimal CalculateFutureValue(
               decimal monthlyInvestesment, decimal monthlyInterestRate, int months)
        {
            decimal futureVale = 0m;
            for (int i = 0; i < months; i++)
            {
                futureVale = (futureVale + monthlyInvestesment)
                    * (1 + monthlyInterestRate);
            }
            return futureVale;
        }

       


        // method for checking
        public bool IsValidData()
        {
            return
                IsPresent(txtmonthlyinvestment, "Monthly Investment") &&
                IsDecimal(txtmonthlyinvestment, "Monthly Investment") &&
                IsWithinRange(txtmonthlyinvestment, "Monthly Investment", 1, 1000) &&
                IsPresent(txtyearlyinterestrate, "Yearly Interest Rate") &&
                IsDecimal(txtyearlyinterestrate, "Yearly Interest Rate") &&
                IsWithinRange(txtyearlyinterestrate, "Yearly Interest Rate", 1, 20) &&
                IsPresent(txtnumberofyears, "Number of Years") &&
                IsInt32(txtnumberofyears, "Number of Years") &&
                IsWithinRange(txtnumberofyears, "Number of Years", 1, 40);
        }

        public bool IsPresent(TextBox textBox, string name)
        {
            if (textBox.Text == "")
            {
                MessageBox.Show(name + " is a required field.", "Entry  Error");
                textBox.Focus();
                return false;
            }
            return true;
        }

        public bool IsDecimal(TextBox textBox, string name)
        {
            try
            {
                Convert.ToDecimal(textBox.Text);
                return true;
            }
            catch (FormatException)
            {
                MessageBox.Show(name + " must be a decimal value.", "Entry Error");
                textBox.Focus();
                return false;
            }
        }

        public bool IsInt32(TextBox textBox, string name)
        {
            try
            {
                Convert.ToInt32(textBox.Text);
                return true;
            }
            catch (FormatException)
            {
                MessageBox.Show(name + " must be an integer.", "Entry Error");
                textBox.Focus();
                return false;
            }
        }

        public bool IsWithinRange(TextBox textBox, string name, decimal min, decimal max)
        {
            decimal number = Convert.ToDecimal(textBox.Text);
            if (number < min || number > max)
            {
                MessageBox.Show(name + " must be between " + min + " and " + max + ".", "Entry Error");
                textBox.Focus();
                return false;
            }
            return true;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void ClearFutureValue(object sender, EventArgs e)
        {
            txtfuturevales.Text = "";
        }

        private void btnexit_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
