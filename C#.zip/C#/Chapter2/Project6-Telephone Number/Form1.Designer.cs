﻿namespace TelephoneNumbers
{
    partial class ConverttoNumericOnly
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAlphanumericNumber = new System.Windows.Forms.Label();
            this.lblnumericOnly = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btnConverttoNumericOnly = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblAlphanumericNumber
            // 
            this.lblAlphanumericNumber.AutoSize = true;
            this.lblAlphanumericNumber.Location = new System.Drawing.Point(91, 87);
            this.lblAlphanumericNumber.Name = "lblAlphanumericNumber";
            this.lblAlphanumericNumber.Size = new System.Drawing.Size(140, 16);
            this.lblAlphanumericNumber.TabIndex = 0;
            this.lblAlphanumericNumber.Text = "Alphanumeric Number";
            // 
            // lblnumericOnly
            // 
            this.lblnumericOnly.AutoSize = true;
            this.lblnumericOnly.Location = new System.Drawing.Point(107, 158);
            this.lblnumericOnly.Name = "lblnumericOnly";
            this.lblnumericOnly.Size = new System.Drawing.Size(87, 16);
            this.lblnumericOnly.TabIndex = 1;
            this.lblnumericOnly.Text = "Numeric Only";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(280, 94);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(280, 158);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(100, 22);
            this.textBox2.TabIndex = 3;
            // 
            // btnConverttoNumericOnly
            // 
            this.btnConverttoNumericOnly.Location = new System.Drawing.Point(119, 243);
            this.btnConverttoNumericOnly.Name = "btnConverttoNumericOnly";
            this.btnConverttoNumericOnly.Size = new System.Drawing.Size(99, 71);
            this.btnConverttoNumericOnly.TabIndex = 4;
            this.btnConverttoNumericOnly.Text = "&Convert to Numeric Only";
            this.btnConverttoNumericOnly.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(316, 243);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 71);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            // 
            // ConverttoNumericOnly
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnConverttoNumericOnly);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblnumericOnly);
            this.Controls.Add(this.lblAlphanumericNumber);
            this.Name = "ConverttoNumericOnly";
            this.Text = "Telephone numbers";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAlphanumericNumber;
        private System.Windows.Forms.Label lblnumericOnly;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button btnConverttoNumericOnly;
        private System.Windows.Forms.Button btnExit;
    }
}

