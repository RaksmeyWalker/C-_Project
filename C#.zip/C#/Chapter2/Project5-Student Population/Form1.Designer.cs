﻿namespace DtudentPopulation
{
    partial class Studentpopulation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNumberofstudenttoday = new System.Windows.Forms.Label();
            this.lblAnnualgrowthrate = new System.Windows.Forms.Label();
            this.lblNumberofyears = new System.Windows.Forms.Label();
            this.lblProjectnumberofstudents = new System.Windows.Forms.Label();
            this.btnProjectStudentpopulation = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblNumberofstudenttoday
            // 
            this.lblNumberofstudenttoday.AutoSize = true;
            this.lblNumberofstudenttoday.Location = new System.Drawing.Point(115, 82);
            this.lblNumberofstudenttoday.Name = "lblNumberofstudenttoday";
            this.lblNumberofstudenttoday.Size = new System.Drawing.Size(152, 16);
            this.lblNumberofstudenttoday.TabIndex = 0;
            this.lblNumberofstudenttoday.Text = "Number of student today";
            // 
            // lblAnnualgrowthrate
            // 
            this.lblAnnualgrowthrate.AutoSize = true;
            this.lblAnnualgrowthrate.Location = new System.Drawing.Point(118, 131);
            this.lblAnnualgrowthrate.Name = "lblAnnualgrowthrate";
            this.lblAnnualgrowthrate.Size = new System.Drawing.Size(116, 16);
            this.lblAnnualgrowthrate.TabIndex = 1;
            this.lblAnnualgrowthrate.Text = "Annual growth rate";
            // 
            // lblNumberofyears
            // 
            this.lblNumberofyears.AutoSize = true;
            this.lblNumberofyears.Location = new System.Drawing.Point(118, 179);
            this.lblNumberofyears.Name = "lblNumberofyears";
            this.lblNumberofyears.Size = new System.Drawing.Size(106, 16);
            this.lblNumberofyears.TabIndex = 2;
            this.lblNumberofyears.Text = "Number of years";
            // 
            // lblProjectnumberofstudents
            // 
            this.lblProjectnumberofstudents.AutoSize = true;
            this.lblProjectnumberofstudents.Location = new System.Drawing.Point(118, 242);
            this.lblProjectnumberofstudents.Name = "lblProjectnumberofstudents";
            this.lblProjectnumberofstudents.Size = new System.Drawing.Size(164, 16);
            this.lblProjectnumberofstudents.TabIndex = 3;
            this.lblProjectnumberofstudents.Text = "Project number of students";
            // 
            // btnProjectStudentpopulation
            // 
            this.btnProjectStudentpopulation.Location = new System.Drawing.Point(175, 342);
            this.btnProjectStudentpopulation.Name = "btnProjectStudentpopulation";
            this.btnProjectStudentpopulation.Size = new System.Drawing.Size(107, 62);
            this.btnProjectStudentpopulation.TabIndex = 4;
            this.btnProjectStudentpopulation.Text = "&Project Student population";
            this.btnProjectStudentpopulation.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(375, 342);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 62);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(323, 242);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 6;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(323, 79);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 22);
            this.textBox2.TabIndex = 7;
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(323, 142);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 22);
            this.textBox3.TabIndex = 8;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(323, 193);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 22);
            this.textBox4.TabIndex = 9;
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Studentpopulation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnProjectStudentpopulation);
            this.Controls.Add(this.lblProjectnumberofstudents);
            this.Controls.Add(this.lblNumberofyears);
            this.Controls.Add(this.lblAnnualgrowthrate);
            this.Controls.Add(this.lblNumberofstudenttoday);
            this.Name = "Studentpopulation";
            this.Text = "Student Population";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNumberofstudenttoday;
        private System.Windows.Forms.Label lblAnnualgrowthrate;
        private System.Windows.Forms.Label lblNumberofyears;
        private System.Windows.Forms.Label lblProjectnumberofstudents;
        private System.Windows.Forms.Button btnProjectStudentpopulation;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
    }
}

