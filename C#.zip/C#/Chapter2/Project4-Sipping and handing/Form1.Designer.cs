﻿namespace Sippingandhanding
{
    partial class SippingandHandling
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblOrderTotal = new System.Windows.Forms.Label();
            this.lblCustomer = new System.Windows.Forms.Label();
            this.lblshipping = new System.Windows.Forms.Label();
            this.lblsales = new System.Windows.Forms.Label();
            this.lblGrandTotal = new System.Windows.Forms.Label();
            this.btnCalculateGrandTotal = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.txtbox1 = new System.Windows.Forms.TextBox();
            this.txtbox2 = new System.Windows.Forms.TextBox();
            this.txtbox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.txtbox5 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblOrderTotal
            // 
            this.lblOrderTotal.AutoSize = true;
            this.lblOrderTotal.Location = new System.Drawing.Point(74, 48);
            this.lblOrderTotal.Name = "lblOrderTotal";
            this.lblOrderTotal.Size = new System.Drawing.Size(75, 16);
            this.lblOrderTotal.TabIndex = 0;
            this.lblOrderTotal.Text = "Order Total";
            // 
            // lblCustomer
            // 
            this.lblCustomer.AutoSize = true;
            this.lblCustomer.Location = new System.Drawing.Point(71, 110);
            this.lblCustomer.Name = "lblCustomer";
            this.lblCustomer.Size = new System.Drawing.Size(268, 16);
            this.lblCustomer.TabIndex = 1;
            this.lblCustomer.Text = "Customer Type (Preferred N=non-Preferred)";
            // 
            // lblshipping
            // 
            this.lblshipping.AutoSize = true;
            this.lblshipping.Location = new System.Drawing.Point(74, 166);
            this.lblshipping.Name = "lblshipping";
            this.lblshipping.Size = new System.Drawing.Size(266, 16);
            this.lblshipping.TabIndex = 2;
            this.lblshipping.Text = "Shipping Costs (free for Preferred customer)";
            // 
            // lblsales
            // 
            this.lblsales.AutoSize = true;
            this.lblsales.Location = new System.Drawing.Point(74, 220);
            this.lblsales.Name = "lblsales";
            this.lblsales.Size = new System.Drawing.Size(98, 16);
            this.lblsales.TabIndex = 3;
            this.lblsales.Text = "Sales Tax (7%)";
            // 
            // lblGrandTotal
            // 
            this.lblGrandTotal.AutoSize = true;
            this.lblGrandTotal.Location = new System.Drawing.Point(74, 275);
            this.lblGrandTotal.Name = "lblGrandTotal";
            this.lblGrandTotal.Size = new System.Drawing.Size(78, 16);
            this.lblGrandTotal.TabIndex = 4;
            this.lblGrandTotal.Text = "Grand Total";
            // 
            // btnCalculateGrandTotal
            // 
            this.btnCalculateGrandTotal.Location = new System.Drawing.Point(165, 332);
            this.btnCalculateGrandTotal.Name = "btnCalculateGrandTotal";
            this.btnCalculateGrandTotal.Size = new System.Drawing.Size(93, 45);
            this.btnCalculateGrandTotal.TabIndex = 5;
            this.btnCalculateGrandTotal.Text = "&Calculate Grand Total";
            this.btnCalculateGrandTotal.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(367, 332);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 45);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            // 
            // txtbox1
            // 
            this.txtbox1.Location = new System.Drawing.Point(367, 220);
            this.txtbox1.Name = "txtbox1";
            this.txtbox1.ReadOnly = true;
            this.txtbox1.Size = new System.Drawing.Size(100, 22);
            this.txtbox1.TabIndex = 7;
            this.txtbox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtbox2
            // 
            this.txtbox2.Location = new System.Drawing.Point(367, 166);
            this.txtbox2.Name = "txtbox2";
            this.txtbox2.ReadOnly = true;
            this.txtbox2.Size = new System.Drawing.Size(100, 22);
            this.txtbox2.TabIndex = 8;
            // 
            // txtbox3
            // 
            this.txtbox3.Location = new System.Drawing.Point(367, 48);
            this.txtbox3.Name = "txtbox3";
            this.txtbox3.Size = new System.Drawing.Size(100, 22);
            this.txtbox3.TabIndex = 9;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(367, 110);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 22);
            this.textBox4.TabIndex = 10;
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtbox5
            // 
            this.txtbox5.Location = new System.Drawing.Point(367, 275);
            this.txtbox5.Name = "txtbox5";
            this.txtbox5.ReadOnly = true;
            this.txtbox5.Size = new System.Drawing.Size(100, 22);
            this.txtbox5.TabIndex = 11;
            // 
            // SippingandHandling
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtbox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.txtbox3);
            this.Controls.Add(this.txtbox2);
            this.Controls.Add(this.txtbox1);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCalculateGrandTotal);
            this.Controls.Add(this.lblGrandTotal);
            this.Controls.Add(this.lblsales);
            this.Controls.Add(this.lblshipping);
            this.Controls.Add(this.lblCustomer);
            this.Controls.Add(this.lblOrderTotal);
            this.Name = "SippingandHandling";
            this.Text = "Sipping and Handling";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblOrderTotal;
        private System.Windows.Forms.Label lblCustomer;
        private System.Windows.Forms.Label lblshipping;
        private System.Windows.Forms.Label lblsales;
        private System.Windows.Forms.Label lblGrandTotal;
        private System.Windows.Forms.Button btnCalculateGrandTotal;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtbox1;
        private System.Windows.Forms.TextBox txtbox2;
        private System.Windows.Forms.TextBox txtbox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox txtbox5;
    }
}

