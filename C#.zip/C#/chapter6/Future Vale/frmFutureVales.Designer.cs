﻿namespace Future_Value
{
    partial class frmFutureVales
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtmonthlyinvestment = new System.Windows.Forms.TextBox();
            this.txtyearlyinterestrate = new System.Windows.Forms.TextBox();
            this.txtnumberofyears = new System.Windows.Forms.TextBox();
            this.txtfuturevales = new System.Windows.Forms.TextBox();
            this.btncaluclate = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(109, 133);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Yearly Interest rate :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(112, 189);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Number of years :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(112, 254);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "Future Vales :";
            // 
            // txtmonthlyinvestment
            // 
            this.txtmonthlyinvestment.Location = new System.Drawing.Point(444, 58);
            this.txtmonthlyinvestment.Name = "txtmonthlyinvestment";
            this.txtmonthlyinvestment.Size = new System.Drawing.Size(100, 22);
            this.txtmonthlyinvestment.TabIndex = 1;
            this.txtmonthlyinvestment.TextChanged += new System.EventHandler(this.ClearFutureValue);

            // 
            // txtyearlyinterestrate
            // 
            this.txtyearlyinterestrate.Location = new System.Drawing.Point(444, 115);
            this.txtyearlyinterestrate.Name = "txtyearlyinterestrate";
            this.txtyearlyinterestrate.Size = new System.Drawing.Size(100, 22);
            this.txtyearlyinterestrate.TabIndex = 3;
            this.txtyearlyinterestrate.TextChanged += new System.EventHandler(this.ClearFutureValue);
            // 
            // txtnumberofyears
            // 
            this.txtnumberofyears.Location = new System.Drawing.Point(444, 182);
            this.txtnumberofyears.Name = "txtnumberofyears";
            this.txtnumberofyears.Size = new System.Drawing.Size(100, 22);
            this.txtnumberofyears.TabIndex = 5;
            // 
            // txtfuturevales
            // 
            this.txtfuturevales.Location = new System.Drawing.Point(444, 247);
            this.txtfuturevales.Name = "txtfuturevales";
            this.txtfuturevales.ReadOnly = true;
            this.txtfuturevales.Size = new System.Drawing.Size(100, 22);
            this.txtfuturevales.TabIndex = 7;
            // 
            // btncaluclate
            // 
            this.btncaluclate.Location = new System.Drawing.Point(158, 340);
            this.btncaluclate.Name = "btncaluclate";
            this.btncaluclate.Size = new System.Drawing.Size(75, 23);
            this.btncaluclate.TabIndex = 8;
            this.btncaluclate.Text = "&Calculate";
            this.btncaluclate.UseVisualStyleBackColor = true;
            this.btncaluclate.Click += new System.EventHandler(this.btncaluclate_Click);
            // 
            // btnexit
            // 
            this.btnexit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnexit.Location = new System.Drawing.Point(331, 340);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(75, 23);
            this.btnexit.TabIndex = 9;
            this.btnexit.Text = "E&xit";
            this.btnexit.UseVisualStyleBackColor = true;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(109, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Monthly Investment :";
            // 
            // frmFutureVales
            // 
            this.AcceptButton = this.btncaluclate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnexit;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.btncaluclate);
            this.Controls.Add(this.txtfuturevales);
            this.Controls.Add(this.txtnumberofyears);
            this.Controls.Add(this.txtyearlyinterestrate);
            this.Controls.Add(this.txtmonthlyinvestment);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Name = "frmFutureVales";
            this.Text = "Future Value";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtmonthlyinvestment;
        private System.Windows.Forms.TextBox txtyearlyinterestrate;
        private System.Windows.Forms.TextBox txtnumberofyears;
        private System.Windows.Forms.TextBox txtfuturevales;
        private System.Windows.Forms.Button btncaluclate;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Label label1;
    }
}

