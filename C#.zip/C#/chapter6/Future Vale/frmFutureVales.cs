﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Future_Value
{
    public partial class frmFutureVales : Form
    {
        public frmFutureVales()
        {
            InitializeComponent();
        }

        private void btncaluclate_Click(object sender, EventArgs e)
        {
            decimal monthlyInvestment = Convert.ToDecimal(txtmonthlyinvestment.Text);
            decimal yearlyInterestRate = Convert.ToDecimal(txtyearlyinterestrate.Text);
            int years = Convert.ToInt32(txtnumberofyears.Text);

            int months = years * 12;
            decimal monthlyInterestRate = yearlyInterestRate / 12 / 100;
            decimal futureValue = this.CalculateFutureVale(
                monthlyInvestment, monthlyInterestRate, months);
           
            txtfuturevales.Text = futureValue.ToString("c");
            txtmonthlyinvestment.Focus();
        }
        private decimal CalculateFutureVale(
               decimal monthlyInvestesment, decimal monthlyInterestRate, int months)
        {
            decimal futureVale = 0m;
            for (int i = 0; i < months; i++)
            {
                futureVale = (futureVale + monthlyInvestesment)
                    * (1 + monthlyInterestRate);
            }
            return futureVale;
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void ClearFutureValue(object sender, EventArgs e)
        {
            txtfuturevales.Text = "";
        }

        private void btnexit_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
