﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Payment
{
    public partial class frmcustomer : Form
    {
        public frmcustomer()
        {
            InitializeComponent();
        }
        bool isDataSaved = true;
        private void frmcustomer_Load(object sender, EventArgs e)
        {

            cboNames.Items.Add("Mike Smith");
            cboNames.Items.Add("Nancy Jones");
        }
        private void DataChanged(object sender,
                System.EventArgs e)
        {
            isDataSaved = false;
        }

        private void btnselectpayment_Click(object sender, EventArgs e)
        {
            Form paymentForm = new frmPayment();
            DialogResult selectedButton
                = paymentForm.ShowDialog();
            if (selectedButton == DialogResult.OK)
            {
                lblpayment.Text = (string)paymentForm.Tag;
            }

        }

        private void btnSave_Click(object sender,
        System.EventArgs e)
        {
            if (IsValidData())
            {
                SaveData();
            }
        }


        private void SaveData()
        {
            cboNames.SelectedIndex = -1;
            lblpayment.Text = "";
            isDataSaved = true;
            cboNames.Focus();
        }

        private bool IsValidData()
        {
            if (cboNames.SelectedIndex == -1)
            {
                MessageBox.Show("You must select a customer.",
                    "Entry Error");
                cboNames.Focus();
                return false;
            }
            if (lblpayment.Text == "")
            {
                MessageBox.Show("You must enter a payment.",
                    "Entry Error");
                return false;
            }
            return true;
        }

        private void btnExit_Click(object sender,
            System.EventArgs e)
        {
            this.Close();
        }

        private void frmcustomer_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (isDataSaved == false)
            {
                string message =
                    "This form contains unsaved data.\n\n" +
                    "Do you want to save it?";

                DialogResult button =
                    MessageBox.Show(message, "Customer",
                    MessageBoxButtons.YesNoCancel,
                    MessageBoxIcon.Warning);

                if (button == DialogResult.Yes)
                {
                    if (IsValidData())
                        this.SaveData();
                    else
                        e.Cancel = true;
                }

            }
        }
    }
}
