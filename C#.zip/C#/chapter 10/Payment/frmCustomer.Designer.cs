﻿namespace Payment
{
    partial class frmcustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblcustomername = new System.Windows.Forms.Label();
            this.lblpaymentmethod = new System.Windows.Forms.Label();
            this.lblpayment = new System.Windows.Forms.Label();
            this.cboNames = new System.Windows.Forms.ComboBox();
            this.btnselectpayment = new System.Windows.Forms.Button();
            this.btnsave = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblcustomername
            // 
            this.lblcustomername.AutoSize = true;
            this.lblcustomername.Location = new System.Drawing.Point(53, 35);
            this.lblcustomername.Name = "lblcustomername";
            this.lblcustomername.Size = new System.Drawing.Size(104, 16);
            this.lblcustomername.TabIndex = 0;
            this.lblcustomername.Text = "Customer name:";
            // 
            // lblpaymentmethod
            // 
            this.lblpaymentmethod.AutoSize = true;
            this.lblpaymentmethod.Location = new System.Drawing.Point(53, 77);
            this.lblpaymentmethod.Name = "lblpaymentmethod";
            this.lblpaymentmethod.Size = new System.Drawing.Size(111, 16);
            this.lblpaymentmethod.TabIndex = 1;
            this.lblpaymentmethod.Text = "Payment method:";
            // 
            // lblpayment
            // 
            this.lblpayment.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblpayment.Location = new System.Drawing.Point(56, 115);
            this.lblpayment.Name = "lblpayment";
            this.lblpayment.Size = new System.Drawing.Size(306, 145);
            this.lblpayment.TabIndex = 2;
            this.lblpayment.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // cboNames
            // 
            this.cboNames.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNames.FormattingEnabled = true;
            this.cboNames.Location = new System.Drawing.Point(223, 48);
            this.cboNames.Name = "cboNames";
            this.cboNames.Size = new System.Drawing.Size(298, 24);
            this.cboNames.TabIndex = 3;
            this.cboNames.TextChanged += new System.EventHandler(this.DataChanged);
            // 
            // btnselectpayment
            // 
            this.btnselectpayment.Location = new System.Drawing.Point(402, 113);
            this.btnselectpayment.Name = "btnselectpayment";
            this.btnselectpayment.Size = new System.Drawing.Size(119, 23);
            this.btnselectpayment.TabIndex = 4;
            this.btnselectpayment.Text = "Select Payment";
            this.btnselectpayment.UseVisualStyleBackColor = true;
            this.btnselectpayment.Click += new System.EventHandler(this.btnselectpayment_Click);
            // 
            // btnsave
            // 
            this.btnsave.Location = new System.Drawing.Point(314, 291);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(75, 23);
            this.btnsave.TabIndex = 5;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnexit
            // 
            this.btnexit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnexit.Location = new System.Drawing.Point(423, 291);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(75, 23);
            this.btnexit.TabIndex = 6;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = true;
            this.btnexit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmcustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnexit;
            this.ClientSize = new System.Drawing.Size(563, 384);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.btnselectpayment);
            this.Controls.Add(this.cboNames);
            this.Controls.Add(this.lblpayment);
            this.Controls.Add(this.lblpaymentmethod);
            this.Controls.Add(this.lblcustomername);
            this.Name = "frmcustomer";
            this.Text = "Customer";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmcustomer_FormClosing);
            this.Load += new System.EventHandler(this.frmcustomer_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblcustomername;
        private System.Windows.Forms.Label lblpaymentmethod;
        private System.Windows.Forms.Label lblpayment;
        private System.Windows.Forms.ComboBox cboNames;
        private System.Windows.Forms.Button btnselectpayment;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.Button btnexit;
    }
}

