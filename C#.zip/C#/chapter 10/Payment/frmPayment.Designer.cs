﻿namespace Payment
{
    partial class frmPayment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdobillcustomer = new System.Windows.Forms.RadioButton();
            this.rdocreditcard = new System.Windows.Forms.RadioButton();
            this.lblcreditcardtype = new System.Windows.Forms.Label();
            this.lstCreditCardType = new System.Windows.Forms.ListBox();
            this.lblcardnumber = new System.Windows.Forms.Label();
            this.txtCardNumber = new System.Windows.Forms.TextBox();
            this.lblExpirationdate = new System.Windows.Forms.Label();
            this.cboExpriationMonth = new System.Windows.Forms.ComboBox();
            this.cboExpirationYear = new System.Windows.Forms.ComboBox();
            this.chkDefault = new System.Windows.Forms.CheckBox();
            this.btnok = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdobillcustomer);
            this.groupBox1.Controls.Add(this.rdocreditcard);
            this.groupBox1.Location = new System.Drawing.Point(55, 33);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(555, 61);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Billing";
            // 
            // rdobillcustomer
            // 
            this.rdobillcustomer.AutoSize = true;
            this.rdobillcustomer.Location = new System.Drawing.Point(330, 21);
            this.rdobillcustomer.Name = "rdobillcustomer";
            this.rdobillcustomer.Size = new System.Drawing.Size(104, 20);
            this.rdobillcustomer.TabIndex = 9;
            this.rdobillcustomer.Text = "Bill customer";
            this.rdobillcustomer.UseVisualStyleBackColor = true;
            // 
            // rdocreditcard
            // 
            this.rdocreditcard.AutoSize = true;
            this.rdocreditcard.Checked = true;
            this.rdocreditcard.Location = new System.Drawing.Point(62, 21);
            this.rdocreditcard.Name = "rdocreditcard";
            this.rdocreditcard.Size = new System.Drawing.Size(93, 20);
            this.rdocreditcard.TabIndex = 8;
            this.rdocreditcard.TabStop = true;
            this.rdocreditcard.Text = "Credit card";
            this.rdocreditcard.UseVisualStyleBackColor = true;
            this.rdocreditcard.CheckedChanged += new System.EventHandler(this.Billing_CheckedChanged);
            // 
            // lblcreditcardtype
            // 
            this.lblcreditcardtype.AutoSize = true;
            this.lblcreditcardtype.Location = new System.Drawing.Point(52, 137);
            this.lblcreditcardtype.Name = "lblcreditcardtype";
            this.lblcreditcardtype.Size = new System.Drawing.Size(112, 16);
            this.lblcreditcardtype.TabIndex = 10;
            this.lblcreditcardtype.Text = "Credit Card Type:";
            // 
            // lstCreditCardType
            // 
            this.lstCreditCardType.FormattingEnabled = true;
            this.lstCreditCardType.ItemHeight = 16;
            this.lstCreditCardType.Location = new System.Drawing.Point(196, 137);
            this.lstCreditCardType.Name = "lstCreditCardType";
            this.lstCreditCardType.Size = new System.Drawing.Size(414, 52);
            this.lstCreditCardType.TabIndex = 0;
            // 
            // lblcardnumber
            // 
            this.lblcardnumber.AutoSize = true;
            this.lblcardnumber.Location = new System.Drawing.Point(52, 229);
            this.lblcardnumber.Name = "lblcardnumber";
            this.lblcardnumber.Size = new System.Drawing.Size(90, 16);
            this.lblcardnumber.TabIndex = 11;
            this.lblcardnumber.Text = "Card Number:";
            // 
            // txtCardNumber
            // 
            this.txtCardNumber.Location = new System.Drawing.Point(195, 215);
            this.txtCardNumber.Multiline = true;
            this.txtCardNumber.Name = "txtCardNumber";
            this.txtCardNumber.Size = new System.Drawing.Size(415, 39);
            this.txtCardNumber.TabIndex = 1;
            // 
            // lblExpirationdate
            // 
            this.lblExpirationdate.AutoSize = true;
            this.lblExpirationdate.Location = new System.Drawing.Point(52, 281);
            this.lblExpirationdate.Name = "lblExpirationdate";
            this.lblExpirationdate.Size = new System.Drawing.Size(99, 16);
            this.lblExpirationdate.TabIndex = 12;
            this.lblExpirationdate.Text = "Expiration date:";
            // 
            // cboExpriationMonth
            // 
            this.cboExpriationMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboExpriationMonth.FormattingEnabled = true;
            this.cboExpriationMonth.Location = new System.Drawing.Point(195, 273);
            this.cboExpriationMonth.Name = "cboExpriationMonth";
            this.cboExpriationMonth.Size = new System.Drawing.Size(164, 24);
            this.cboExpriationMonth.TabIndex = 2;
            // 
            // cboExpirationYear
            // 
            this.cboExpirationYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboExpirationYear.FormattingEnabled = true;
            this.cboExpirationYear.Location = new System.Drawing.Point(437, 273);
            this.cboExpirationYear.Name = "cboExpirationYear";
            this.cboExpirationYear.Size = new System.Drawing.Size(164, 24);
            this.cboExpirationYear.TabIndex = 3;
            // 
            // chkDefault
            // 
            this.chkDefault.AutoSize = true;
            this.chkDefault.Checked = true;
            this.chkDefault.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkDefault.Location = new System.Drawing.Point(67, 377);
            this.chkDefault.Name = "chkDefault";
            this.chkDefault.Size = new System.Drawing.Size(193, 20);
            this.chkDefault.TabIndex = 4;
            this.chkDefault.Text = "Set as default biling method";
            this.chkDefault.UseVisualStyleBackColor = true;
            // 
            // btnok
            // 
            this.btnok.Location = new System.Drawing.Point(312, 415);
            this.btnok.Name = "btnok";
            this.btnok.Size = new System.Drawing.Size(99, 51);
            this.btnok.TabIndex = 5;
            this.btnok.Text = "Ok";
            this.btnok.UseVisualStyleBackColor = true;
            this.btnok.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(437, 415);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(99, 51);
            this.btnCancel.TabIndex = 6;
            this.btnCancel.Text = "Cencel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // frmPayment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(656, 508);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnok);
            this.Controls.Add(this.chkDefault);
            this.Controls.Add(this.cboExpirationYear);
            this.Controls.Add(this.cboExpriationMonth);
            this.Controls.Add(this.lblExpirationdate);
            this.Controls.Add(this.txtCardNumber);
            this.Controls.Add(this.lblcardnumber);
            this.Controls.Add(this.lstCreditCardType);
            this.Controls.Add(this.lblcreditcardtype);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmPayment";
            this.Text = "Payment";
            this.Load += new System.EventHandler(this.frmPayment_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdobillcustomer;
        private System.Windows.Forms.RadioButton rdocreditcard;
        private System.Windows.Forms.Label lblcreditcardtype;
        private System.Windows.Forms.ListBox lstCreditCardType;
        private System.Windows.Forms.Label lblcardnumber;
        private System.Windows.Forms.TextBox txtCardNumber;
        private System.Windows.Forms.Label lblExpirationdate;
        private System.Windows.Forms.ComboBox cboExpriationMonth;
        private System.Windows.Forms.ComboBox cboExpirationYear;
        private System.Windows.Forms.CheckBox chkDefault;
        private System.Windows.Forms.Button btnok;
        private System.Windows.Forms.Button btnCancel;
    }
}